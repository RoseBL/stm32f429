﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;


namespace 智能农业网络监控系统
{

    public partial class Form1 : Form
    {
        /**************************************全局变量***********************************/
        string ip_protc = null;
        string ip_addr = null;
        int ip_port = 0;
        int net_type = 0;
        int bt_liten_count = 0;
        int Rev_flag = 0;
        int show_flag = 0;
        int bt_drwa_count = 0;
        UInt64 point_count = 0;
        string Rev_buffer = null;
        string get_Tdata = null;
        string get_Hdata = null;
        string get_Idata = null;
        string set_Tdata = null;
        string set_Hdata = null;
        string set_Idata = null;
        Thread th_listen;
        Thread th_recive;
        Thread th_draw ; 
        Socket socketSend;

        /// <summary>
        /// 初始化函数
        /// </summary>
        public Form1()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 连接按钮事件  判断网络服务类型 创建socket
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Bt_Listen_Click(object sender, EventArgs e)
        {
            /*发送标志初始化*/
            Rev_flag = 0;
            net_type = 0;

            bt_liten_count = ~bt_liten_count;
            /**获取控件中选择的值**/
            ip_protc = Cmbox_Prot.SelectedItem.ToString();
            ip_addr = Text_Ip.Text.ToString();
            ip_port = Convert.ToInt32(Text_Port.Text.ToString());

            /**判断选择的网络传输模式**/

            if (string.Compare(ip_protc, "TCP Server") == 0)
            {
                net_type = 1;
            }
            else if (string.Compare(ip_protc, "TCP Client") == 0)
            {
                net_type = 2;
            }
            else
            {
                net_type = 3;
            }
            /**改变连接按钮状态**/
            if (bt_liten_count != 0)
            {
                Bt_Listen.Text = "断开连接";
                /**将网络设置选项状态变为不可操作**/
                Cmbox_Prot.Enabled = false;
                Text_Ip.Enabled = false;
                Text_Port.Enabled = false;
                pictureBox1.Image = Image.FromFile("led_2.png");

                /**创建套接字**/
                Socket sersock = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                /**设置ip地址**/
                IPAddress serip = IPAddress.Parse(ip_addr);
                /**创建端口号对象**/
                IPEndPoint point = new IPEndPoint(serip, ip_port);
                /**监听**/
                sersock.Bind(point);
                sersock.Listen(10);
                System.Console.WriteLine("监听成功");
                /**创建一个线程**/
                th_listen = new Thread(Listen);
                /**线程在后台执行**/
                th_listen.IsBackground = true;
                /****/
                th_listen.Start(sersock);
            }
               
            else
            {
                Bt_Listen.Text = "开始监听";
                /**将网络设置选项状态变为可操作**/
                Cmbox_Prot.Enabled = true;
                Text_Ip.Enabled = true;
                Text_Port.Enabled = true;
                pictureBox1.Image = Image.FromFile("led_3.png");
                //th_listen.Abort();
                //th_recive.Abort();
                //th_draw.Abort();
                socketSend.Close();
            }

        }

        /// <summary>
        /// 等待客户端的连接 并且创建与之通信用的Socket
        /// </summary>
        /// 
        void Listen(object o)
        {
            Socket sersock = o as Socket;
            //等待客户端的连接 并且创建一个负责通信的Socket
            while (bt_liten_count != 0)
            {
                try
                {
                    //负责跟客户端通信的Socket
                    socketSend = sersock.Accept();
                    /*网络已经连接*/
                    Rev_flag = 1;
                    //将远程连接的客户端的IP地址和Socket存入集合中
                    dicSocket.Add(socketSend.RemoteEndPoint.ToString(), socketSend);
                    //192.168.11.78：连接成功
                    System.Console.WriteLine("连接成功");
                    //开启 一个新线程不停的接受客户端发送过来的消息
                    th_recive = new Thread(Recive);
                    th_recive.Start(socketSend);
                    th_recive.IsBackground = true;           
                }
                catch
                { }
            }
            th_listen.Abort();
        }

        //将远程连接的客户端的IP地址和Socket存入集合中
        Dictionary<string, Socket> dicSocket = new Dictionary<string, Socket>();

        /// <summary>
        /// 服务器端不停的接受客户端发送过来的消息
        /// </summary>
        /// <param name="o"></param>
        void Recive(object o)
        {
            Socket socketSend = o as Socket;
            byte[] buffer = new byte[1024 * 1024 * 2];
            while (bt_liten_count != 0)
            {
                try
                {
                    //客户端连接成功后，服务器应该接受客户端发来的消息
                    //实际接受到的有效字节数
                    show_flag = 0;
                    /*会阻塞在接收*/
                    int r = socketSend.Receive(buffer);
                    if (r == 0)
                        break;
                    show_flag = 1;

                    Rev_buffer = Encoding.UTF8.GetString(buffer, 0, r);
                    /**跨线程访问控件**/
                    if (Text_Rev.InvokeRequired)
                    {
                        // 当一个控件的InvokeRequired属性值为真时，说明有一个创建它以外的线程想访问它
                        Action<string> actionDelegate = (x) =>
                        {
                            /*这里才是显示内容的*/
                            this.Text_Rev.AppendText(x.ToString() + "\r\n");
                        };

                        this.Text_Rev.Invoke(actionDelegate, Rev_buffer);
                    }
                }
                catch
                { }
            }
            th_recive.Abort();
        }


        /****************************************************************************
         * 函数名称：Cmbox_Prot_SelectedIndexChanged
         * 描述：网络服务类型改变事件
        ***************************************************************************/
        private void Cmbox_Prot_SelectedIndexChanged(object sender, EventArgs e)
        {
            ip_protc = Cmbox_Prot.SelectedItem.ToString();
            if (string.Compare(ip_protc, "TCP Server") == 0)
            {
                Lab_Ip.Text = "本机ip地址";
            }
            else if (string.Compare(ip_protc, "TCP Client") == 0)
            {
                Lab_Ip.Text = "服务器ip地址";
            }
            else
            {
                Lab_Ip.Text = "服务器ip地址";
            }
        }


        /// <summary>
        /// 发送按钮事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Bt_Send_Click(object sender, EventArgs e)
        {
            if (Rev_flag == 0 && net_type == 1)
            {
                MessageBox.Show("服务器已启动单未建立网络连接,请启动客户端！", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (net_type == 0)
            {
                MessageBox.Show("请选择网络连接类型并建立连接！", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else if (Text_Send.Text.Trim() == String.Empty)
            {
                MessageBox.Show("发送的内容不能为空！", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                btnSend_Click(sender, e);
            }
        }
        /// <summary>
        /// 服务器给客户端发送消息
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSend_Click(object sender, EventArgs e)
        {
            string str = Text_Send.Text;
            if (str == null)
                MessageBox.Show("请填入要发送的数据！", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            byte[] buffer = System.Text.Encoding.UTF8.GetBytes(str);
            List<byte> list = new List<byte>();
            list.Add(0);
            list.AddRange(buffer);
            //将泛型集合转换为数组
            byte[] newBuffer = list.ToArray();
            socketSend.Send(buffer);
        }
        /// <summary>
        /// 清空接收区
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Lab_ClearShow_Click(object sender, EventArgs e)
        {
            Text_Rev.Text = null;
        }

        /// <summary>
        /// 清空发送区
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Lab_Indata_Click(object sender, EventArgs e)
        {
            Text_Send.Text = null;
        }


        /// <summary>
        /// 设置温度曲线颜色
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void S_Text_color_T_MouseDown(object sender, MouseEventArgs e)
        {
            Color_set.ShowDialog();
            S_Text_color_T.BackColor = Color_set.Color;
        }
        /// <summary>
        /// 设置湿度曲线颜色
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void S_Text_color_H_MouseDown(object sender, MouseEventArgs e)
        {
            Color_set.ShowDialog();
            S_Text_color_H.BackColor = Color_set.Color;
        }
        /// <summary>
        /// 设置光照曲线颜色
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void S_Text_color_I_MouseDown(object sender, MouseEventArgs e)
        {
            Color_set.ShowDialog();
            S_Text_color_I.BackColor = Color_set.Color;
        }
        /// <summary>
        /// 设置得到的温度曲线颜色
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void G_Text_color_T_MouseDown(object sender, MouseEventArgs e)
        {
            Color_set.ShowDialog();
            G_Text_color_T.BackColor = Color_set.Color;
        }
        /// <summary>
        /// 设置得到的湿度曲线颜色
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void G_Text_color_H_MouseDown(object sender, MouseEventArgs e)
        {
            Color_set.ShowDialog();
            G_Text_color_H.BackColor = Color_set.Color;
        }

        /// <summary>
        /// 设置得到的光照曲线颜色
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void G_Text_color_I_MouseDown(object sender, MouseEventArgs e)
        {
            Color_set.ShowDialog();
            G_Text_color_I.BackColor = Color_set.Color;
        }

        /// <summary>
        /// 绘制曲线
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button2_Click(object sender, EventArgs e)
        {
            bt_drwa_count = ~bt_drwa_count;
            /*绘制6条曲线*/
            /*设置6条曲线的颜色*/
            chart1.Series[0].Color = S_Text_color_T.BackColor;
            chart1.Series[1].Color = S_Text_color_H.BackColor;
            chart1.Series[2].Color = S_Text_color_I.BackColor;
            chart1.Series[3].Color = G_Text_color_T.BackColor;
            chart1.Series[4].Color = G_Text_color_H.BackColor;
            chart1.Series[5].Color = G_Text_color_I.BackColor;
            if (Rev_flag == 0 && net_type == 1)
            {
                MessageBox.Show("服务器已启动单未建立网络连接,请启动客户端！", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                bt_drwa_count = 0;
            }
            else if (net_type == 0)
            {
                MessageBox.Show("请选择网络连接类型并建立连接！", "警告", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                bt_drwa_count = 0;
            }
            else
            {
                if (bt_drwa_count != 0)
                {
                    bt_Show_point.Text = "停止显示";
                    /*这里需要开一个线程出来 更新波形数据*/

                    th_draw = new Thread(GetPoint);
                    th_draw.IsBackground = true;
                    th_draw.Start();
                }
                else
                {
                    bt_Show_point.Text = "显示波形";
                }
            }
        }
        /// <summary>
        /// 分离接收的数据  更新曲线显示
        /// </summary>
        void GetPoint()
        {
            char[] delimit = new char[] {':'};
            while (true)
            {
                if (bt_drwa_count == 0)
                    th_draw.Abort();
                /**创建一个列表**/
                List<string> str_fam = new List<string>();
                if (show_flag ==1)
                {
                    /**分离数据**/
                    string str = Rev_buffer;
                    /**这里要根据定义的协议类型来进行解析**/
                    /**发送的协议类型为T32:H31:I5**/
                    foreach (string substr in str.Split(delimit))
                    {
                        str_fam.Add(substr);
                    }

                    /**进行数据解析**/
                    foreach (string s in str_fam)
                    {
                        string str_type = null;
                        string str_data = null;
                        str_type = s.Substring(0, 1);
                        str_data = s.Substring(1, s.Length-1);
                        switch (str_type)
                        {
                            case "T":
                                get_Tdata = str_data;
                                break;
                            case "H":
                                get_Hdata = str_data;
                                break;
                            case "I":
                                get_Idata = str_data;
                                break;
                            default:
                                break;
                        }

                    }             
                    /**读取设置的值**/
                    if (Combox_Set_T.InvokeRequired)
                    {
                        // 当一个控件的InvokeRequired属性值为真时，说明有一个创建它以外的线程想访问它
                        Action<string> actionDelegate = (x) =>
                        {
                            set_Tdata = Combox_Set_T.SelectedItem.ToString(); ;
                        };

                        this.Combox_Set_T.Invoke(actionDelegate, set_Tdata);
                    }
                    if (Combox_Set_H.InvokeRequired)
                    {
                        // 当一个控件的InvokeRequired属性值为真时，说明有一个创建它以外的线程想访问它
                        Action<string> actionDelegate = (x) =>
                        {
                            set_Hdata = Combox_Set_H.SelectedItem.ToString();
                            set_Hdata = set_Hdata.Substring(0,set_Hdata.Length-1);
                        };
                        this.Combox_Set_H.Invoke(actionDelegate, set_Hdata);

                    }
                    if (Combox_Set_I.InvokeRequired)
                    {
                        // 当一个控件的InvokeRequired属性值为真时，说明有一个创建它以外的线程想访问它
                        Action<string> actionDelegate = (x) =>
                        {
                            set_Idata = Combox_Set_I.SelectedItem.ToString();
                        };
                        this.Combox_Set_I.Invoke(actionDelegate, set_Idata);

                    }

                    /**画线**/
                    /**跨线程访问控件**/
                    if (chart1.InvokeRequired)
                    {
                        // 当一个控件的InvokeRequired属性值为真时，说明有一个创建它以外的线程想访问它
                        Action<string> actionDelegate = (x) =>
                        {
                            /*这里才是显示内容的*/
                            chart1.Series[0].Points.AddXY(point_count, set_Tdata);
                            chart1.Series[1].Points.AddXY(point_count, set_Hdata);
                            chart1.Series[2].Points.AddXY(point_count, set_Idata);
                            chart1.Series[3].Points.AddXY(point_count, get_Tdata);
                            chart1.Series[4].Points.AddXY(point_count, get_Hdata);
                            chart1.Series[5].Points.AddXY(point_count, get_Idata);
                            point_count++;
                        };
                        this.chart1.Invoke(actionDelegate, str);

                    }

                    /**显示得到的值**/
                    if (Texbox_show_T.InvokeRequired)
                    {
                        // 当一个控件的InvokeRequired属性值为真时，说明有一个创建它以外的线程想访问它
                        Action<string> actionDelegate = (x) =>
                        {
                            Texbox_show_T.Text = get_Tdata;
                        };
                        this.Texbox_show_T.Invoke(actionDelegate, get_Tdata);

                    }
                    if (Texbox_show_H.InvokeRequired)
                    {
                        // 当一个控件的InvokeRequired属性值为真时，说明有一个创建它以外的线程想访问它
                        Action<string> actionDelegate = (x) =>
                        {
                            Texbox_show_H.Text = get_Hdata;
                        };
                        this.Texbox_show_H.Invoke(actionDelegate, get_Hdata);

                    }
                    if (Texbox_show_I.InvokeRequired)
                    {
                        // 当一个控件的InvokeRequired属性值为真时，说明有一个创建它以外的线程想访问它
                        Action<string> actionDelegate = (x) =>
                        {
                            Texbox_show_I.Text = get_Idata;
                        };
                        this.Texbox_show_I.Invoke(actionDelegate, get_Idata);

                    }

                }
            }

    }

        /// <summary>
        /// 获取ip地址
        /// </summary>
        /// <returns></returns>
        private string GetAddressIP()
        {
            ///获取本地的IP地址
            string AddressIP = string.Empty;
            foreach (IPAddress _IPAddress in Dns.GetHostEntry(Dns.GetHostName()).AddressList)
            {
                if (_IPAddress.AddressFamily.ToString() == "InterNetwork")
                {
                    AddressIP = _IPAddress.ToString();
                }
            }
            return AddressIP;
        }
        /// <summary>
        /// 窗口加载事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_Load(object sender, EventArgs e)
        {
            chart1.GetToolTipText += new EventHandler<ToolTipEventArgs>(chart1_GetToolTipText);
            Text_Ip.Text = GetAddressIP();
            //MessageBox.Show(GetLocalIPAddress());

        }

        /// <summary>
        /// 程序关闭事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show("确认退出？","系统提示",MessageBoxButtons.OKCancel);
            if (result == DialogResult.OK)
            {
                this.Dispose(true);
                this.Close();
                Application.Exit();
            }
            else
            {

                e.Cancel = true;//取消关闭
            }
        }



        /// <summary>
        /// 鼠标在chart上悬停显示坐标值
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void chart1_GetToolTipText(object sender, ToolTipEventArgs e)
        {
            if (e.HitTestResult.ChartElementType == ChartElementType.DataPoint)
            {
                int i = e.HitTestResult.PointIndex;
                DataPoint dp = e.HitTestResult.Series.Points[i];
                //分别显示x轴和y轴的数值，其中{1:F3},表示显示的是float类型，精确到小数点后3位。  
                e.Text = string.Format("次数:{0};数值:{1:F3} ", dp.XValue, dp.YValues[0]);
            }  
        }

        private void Text_Rev_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
