﻿namespace 智能农业网络监控系统
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.TabControl1 = new System.Windows.Forms.TabControl();
            this.TabPage1 = new System.Windows.Forms.TabPage();
            this.Bt_Send = new System.Windows.Forms.Button();
            this.GroupBox5 = new System.Windows.Forms.GroupBox();
            this.Text_Send = new System.Windows.Forms.TextBox();
            this.GroupBox4 = new System.Windows.Forms.GroupBox();
            this.Lab_Indata = new System.Windows.Forms.Label();
            this.Text_Delay = new System.Windows.Forms.TextBox();
            this.Label6 = new System.Windows.Forms.Label();
            this.Ckbox_SendList = new System.Windows.Forms.CheckedListBox();
            this.GroupBox3 = new System.Windows.Forms.GroupBox();
            this.Lab_ClearShow = new System.Windows.Forms.Label();
            this.Lab_Savadata = new System.Windows.Forms.Label();
            this.Ckbox_RecList = new System.Windows.Forms.CheckedListBox();
            this.GroupBox2 = new System.Windows.Forms.GroupBox();
            this.Text_Rev = new System.Windows.Forms.TextBox();
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Bt_Listen = new System.Windows.Forms.Button();
            this.Text_Port = new System.Windows.Forms.TextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.Text_Ip = new System.Windows.Forms.TextBox();
            this.Lab_Ip = new System.Windows.Forms.Label();
            this.Cmbox_Prot = new System.Windows.Forms.ComboBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.TabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.Texbox_show_I = new System.Windows.Forms.TextBox();
            this.Texbox_show_H = new System.Windows.Forms.TextBox();
            this.Texbox_show_T = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.S_Text_color_I = new System.Windows.Forms.TextBox();
            this.S_Text_color_H = new System.Windows.Forms.TextBox();
            this.S_Text_color_T = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.bt_Show_point = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.G_Text_color_I = new System.Windows.Forms.TextBox();
            this.G_Text_color_H = new System.Windows.Forms.TextBox();
            this.G_Text_color_T = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.Combox_Set_I = new System.Windows.Forms.ComboBox();
            this.Combox_Set_H = new System.Windows.Forms.ComboBox();
            this.Combox_Set_T = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Color_set = new System.Windows.Forms.ColorDialog();
            this.TabControl1.SuspendLayout();
            this.TabPage1.SuspendLayout();
            this.GroupBox5.SuspendLayout();
            this.GroupBox4.SuspendLayout();
            this.GroupBox3.SuspendLayout();
            this.GroupBox2.SuspendLayout();
            this.GroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.TabPage2.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.SuspendLayout();
            // 
            // TabControl1
            // 
            this.TabControl1.Controls.Add(this.TabPage1);
            this.TabControl1.Controls.Add(this.TabPage2);
            this.TabControl1.Font = new System.Drawing.Font("宋体", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TabControl1.Location = new System.Drawing.Point(12, 2);
            this.TabControl1.Name = "TabControl1";
            this.TabControl1.SelectedIndex = 0;
            this.TabControl1.Size = new System.Drawing.Size(990, 595);
            this.TabControl1.TabIndex = 1;
            // 
            // TabPage1
            // 
            this.TabPage1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.TabPage1.Controls.Add(this.Bt_Send);
            this.TabPage1.Controls.Add(this.GroupBox5);
            this.TabPage1.Controls.Add(this.GroupBox4);
            this.TabPage1.Controls.Add(this.GroupBox3);
            this.TabPage1.Controls.Add(this.GroupBox2);
            this.TabPage1.Controls.Add(this.GroupBox1);
            this.TabPage1.Location = new System.Drawing.Point(4, 31);
            this.TabPage1.Name = "TabPage1";
            this.TabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage1.Size = new System.Drawing.Size(982, 560);
            this.TabPage1.TabIndex = 0;
            this.TabPage1.Text = "网络数据";
            // 
            // Bt_Send
            // 
            this.Bt_Send.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Bt_Send.Location = new System.Drawing.Point(834, 508);
            this.Bt_Send.Name = "Bt_Send";
            this.Bt_Send.Size = new System.Drawing.Size(118, 30);
            this.Bt_Send.TabIndex = 7;
            this.Bt_Send.Text = "发送数据";
            this.Bt_Send.UseVisualStyleBackColor = true;
            this.Bt_Send.Click += new System.EventHandler(this.Bt_Send_Click);
            // 
            // GroupBox5
            // 
            this.GroupBox5.Controls.Add(this.Text_Send);
            this.GroupBox5.Font = new System.Drawing.Font("宋体", 11.25F);
            this.GroupBox5.Location = new System.Drawing.Point(21, 361);
            this.GroupBox5.Name = "GroupBox5";
            this.GroupBox5.Size = new System.Drawing.Size(774, 177);
            this.GroupBox5.TabIndex = 6;
            this.GroupBox5.TabStop = false;
            this.GroupBox5.Text = "数据发送";
            // 
            // Text_Send
            // 
            this.Text_Send.Location = new System.Drawing.Point(6, 24);
            this.Text_Send.Multiline = true;
            this.Text_Send.Name = "Text_Send";
            this.Text_Send.Size = new System.Drawing.Size(762, 147);
            this.Text_Send.TabIndex = 0;
            // 
            // GroupBox4
            // 
            this.GroupBox4.Controls.Add(this.Lab_Indata);
            this.GroupBox4.Controls.Add(this.Text_Delay);
            this.GroupBox4.Controls.Add(this.Label6);
            this.GroupBox4.Controls.Add(this.Ckbox_SendList);
            this.GroupBox4.Font = new System.Drawing.Font("宋体", 11.25F);
            this.GroupBox4.Location = new System.Drawing.Point(811, 361);
            this.GroupBox4.Name = "GroupBox4";
            this.GroupBox4.Size = new System.Drawing.Size(164, 141);
            this.GroupBox4.TabIndex = 5;
            this.GroupBox4.TabStop = false;
            this.GroupBox4.Text = "发送区设置";
            // 
            // Lab_Indata
            // 
            this.Lab_Indata.AutoSize = true;
            this.Lab_Indata.Font = new System.Drawing.Font("宋体", 9.75F);
            this.Lab_Indata.Location = new System.Drawing.Point(9, 88);
            this.Lab_Indata.Name = "Lab_Indata";
            this.Lab_Indata.Size = new System.Drawing.Size(59, 13);
            this.Lab_Indata.TabIndex = 7;
            this.Lab_Indata.Text = "清除输入";
            this.Lab_Indata.Click += new System.EventHandler(this.Lab_Indata_Click);
            // 
            // Text_Delay
            // 
            this.Text_Delay.BackColor = System.Drawing.SystemColors.ControlLight;
            this.Text_Delay.Font = new System.Drawing.Font("宋体", 9.75F);
            this.Text_Delay.Location = new System.Drawing.Point(74, 104);
            this.Text_Delay.Multiline = true;
            this.Text_Delay.Name = "Text_Delay";
            this.Text_Delay.Size = new System.Drawing.Size(57, 17);
            this.Text_Delay.TabIndex = 7;
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Font = new System.Drawing.Font("宋体", 9.75F);
            this.Label6.Location = new System.Drawing.Point(9, 108);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(59, 13);
            this.Label6.TabIndex = 6;
            this.Label6.Text = "发送间隔";
            // 
            // Ckbox_SendList
            // 
            this.Ckbox_SendList.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.Ckbox_SendList.Font = new System.Drawing.Font("宋体", 9.75F);
            this.Ckbox_SendList.FormattingEnabled = true;
            this.Ckbox_SendList.Items.AddRange(new object[] {
            "发送完自动清空",
            "按十六进制发送",
            "数据流循环发送"});
            this.Ckbox_SendList.Location = new System.Drawing.Point(6, 28);
            this.Ckbox_SendList.Name = "Ckbox_SendList";
            this.Ckbox_SendList.Size = new System.Drawing.Size(151, 106);
            this.Ckbox_SendList.TabIndex = 0;
            // 
            // GroupBox3
            // 
            this.GroupBox3.Controls.Add(this.Lab_ClearShow);
            this.GroupBox3.Controls.Add(this.Lab_Savadata);
            this.GroupBox3.Controls.Add(this.Ckbox_RecList);
            this.GroupBox3.Font = new System.Drawing.Font("宋体", 11.25F);
            this.GroupBox3.Location = new System.Drawing.Point(811, 215);
            this.GroupBox3.Name = "GroupBox3";
            this.GroupBox3.Size = new System.Drawing.Size(164, 127);
            this.GroupBox3.TabIndex = 4;
            this.GroupBox3.TabStop = false;
            this.GroupBox3.Text = "接收区设置";
            // 
            // Lab_ClearShow
            // 
            this.Lab_ClearShow.AutoSize = true;
            this.Lab_ClearShow.Font = new System.Drawing.Font("宋体", 9.75F);
            this.Lab_ClearShow.Location = new System.Drawing.Point(82, 90);
            this.Lab_ClearShow.Name = "Lab_ClearShow";
            this.Lab_ClearShow.Size = new System.Drawing.Size(59, 13);
            this.Lab_ClearShow.TabIndex = 6;
            this.Lab_ClearShow.Text = "清除显示";
            this.Lab_ClearShow.Click += new System.EventHandler(this.Lab_ClearShow_Click);
            // 
            // Lab_Savadata
            // 
            this.Lab_Savadata.AutoSize = true;
            this.Lab_Savadata.Font = new System.Drawing.Font("宋体", 9.75F);
            this.Lab_Savadata.Location = new System.Drawing.Point(9, 90);
            this.Lab_Savadata.Name = "Lab_Savadata";
            this.Lab_Savadata.Size = new System.Drawing.Size(59, 13);
            this.Lab_Savadata.TabIndex = 1;
            this.Lab_Savadata.Text = "保存数据";
            // 
            // Ckbox_RecList
            // 
            this.Ckbox_RecList.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.Ckbox_RecList.Font = new System.Drawing.Font("宋体", 9.75F);
            this.Ckbox_RecList.FormattingEnabled = true;
            this.Ckbox_RecList.Items.AddRange(new object[] {
            "自动换行显示",
            "十六进制显示",
            "暂停接收显示"});
            this.Ckbox_RecList.Location = new System.Drawing.Point(6, 28);
            this.Ckbox_RecList.Name = "Ckbox_RecList";
            this.Ckbox_RecList.Size = new System.Drawing.Size(151, 89);
            this.Ckbox_RecList.TabIndex = 0;
            // 
            // GroupBox2
            // 
            this.GroupBox2.Controls.Add(this.Text_Rev);
            this.GroupBox2.Font = new System.Drawing.Font("宋体", 11.25F);
            this.GroupBox2.Location = new System.Drawing.Point(21, 6);
            this.GroupBox2.Name = "GroupBox2";
            this.GroupBox2.Size = new System.Drawing.Size(774, 349);
            this.GroupBox2.TabIndex = 3;
            this.GroupBox2.TabStop = false;
            this.GroupBox2.Text = "网络数据接收";
            // 
            // Text_Rev
            // 
            this.Text_Rev.Location = new System.Drawing.Point(6, 20);
            this.Text_Rev.Multiline = true;
            this.Text_Rev.Name = "Text_Rev";
            this.Text_Rev.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.Text_Rev.Size = new System.Drawing.Size(762, 323);
            this.Text_Rev.TabIndex = 0;
            this.Text_Rev.TextChanged += new System.EventHandler(this.Text_Rev_TextChanged);
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.pictureBox1);
            this.GroupBox1.Controls.Add(this.Bt_Listen);
            this.GroupBox1.Controls.Add(this.Text_Port);
            this.GroupBox1.Controls.Add(this.Label3);
            this.GroupBox1.Controls.Add(this.Text_Ip);
            this.GroupBox1.Controls.Add(this.Lab_Ip);
            this.GroupBox1.Controls.Add(this.Cmbox_Prot);
            this.GroupBox1.Controls.Add(this.Label1);
            this.GroupBox1.Font = new System.Drawing.Font("宋体", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.GroupBox1.Location = new System.Drawing.Point(812, 6);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(164, 188);
            this.GroupBox1.TabIndex = 0;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "网络设置";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.pictureBox1.Image = global::智能农业网络监控系统.Properties.Resources.led_3;
            this.pictureBox1.Location = new System.Drawing.Point(14, 154);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(21, 22);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            // 
            // Bt_Listen
            // 
            this.Bt_Listen.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Bt_Listen.Location = new System.Drawing.Point(6, 150);
            this.Bt_Listen.Name = "Bt_Listen";
            this.Bt_Listen.Size = new System.Drawing.Size(118, 30);
            this.Bt_Listen.TabIndex = 2;
            this.Bt_Listen.Text = "开始监听";
            this.Bt_Listen.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.Bt_Listen.UseVisualStyleBackColor = true;
            this.Bt_Listen.Click += new System.EventHandler(this.Bt_Listen_Click);
            // 
            // Text_Port
            // 
            this.Text_Port.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Text_Port.Location = new System.Drawing.Point(6, 122);
            this.Text_Port.Name = "Text_Port";
            this.Text_Port.Size = new System.Drawing.Size(121, 22);
            this.Text_Port.TabIndex = 5;
            this.Text_Port.Text = "5000";
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("宋体", 9.75F);
            this.Label3.Location = new System.Drawing.Point(6, 106);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(72, 13);
            this.Label3.TabIndex = 4;
            this.Label3.Text = "本地端口号";
            // 
            // Text_Ip
            // 
            this.Text_Ip.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Text_Ip.Location = new System.Drawing.Point(6, 81);
            this.Text_Ip.Name = "Text_Ip";
            this.Text_Ip.Size = new System.Drawing.Size(121, 22);
            this.Text_Ip.TabIndex = 3;
            this.Text_Ip.Text = "192.168.1.102";
            // 
            // Lab_Ip
            // 
            this.Lab_Ip.AutoSize = true;
            this.Lab_Ip.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Lab_Ip.Location = new System.Drawing.Point(6, 65);
            this.Lab_Ip.Name = "Lab_Ip";
            this.Lab_Ip.Size = new System.Drawing.Size(47, 13);
            this.Lab_Ip.TabIndex = 2;
            this.Lab_Ip.Text = "本地IP";
            // 
            // Cmbox_Prot
            // 
            this.Cmbox_Prot.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Cmbox_Prot.FormattingEnabled = true;
            this.Cmbox_Prot.Items.AddRange(new object[] {
            "TCP Server",
            "TCP Client",
            "UDP "});
            this.Cmbox_Prot.Location = new System.Drawing.Point(6, 41);
            this.Cmbox_Prot.Name = "Cmbox_Prot";
            this.Cmbox_Prot.Size = new System.Drawing.Size(121, 21);
            this.Cmbox_Prot.TabIndex = 1;
            this.Cmbox_Prot.Text = "TCP Server";
            this.Cmbox_Prot.SelectedIndexChanged += new System.EventHandler(this.Cmbox_Prot_SelectedIndexChanged);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("宋体", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Label1.Location = new System.Drawing.Point(6, 25);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(59, 13);
            this.Label1.TabIndex = 1;
            this.Label1.Text = "协议类型";
            // 
            // TabPage2
            // 
            this.TabPage2.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.TabPage2.Controls.Add(this.groupBox9);
            this.TabPage2.Controls.Add(this.groupBox6);
            this.TabPage2.Controls.Add(this.bt_Show_point);
            this.TabPage2.Controls.Add(this.groupBox11);
            this.TabPage2.Controls.Add(this.groupBox7);
            this.TabPage2.Controls.Add(this.groupBox8);
            this.TabPage2.Font = new System.Drawing.Font("宋体", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.TabPage2.Location = new System.Drawing.Point(4, 31);
            this.TabPage2.Name = "TabPage2";
            this.TabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.TabPage2.Size = new System.Drawing.Size(982, 560);
            this.TabPage2.TabIndex = 1;
            this.TabPage2.Text = "波形显示";
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.Texbox_show_I);
            this.groupBox9.Controls.Add(this.Texbox_show_H);
            this.groupBox9.Controls.Add(this.Texbox_show_T);
            this.groupBox9.Controls.Add(this.label10);
            this.groupBox9.Controls.Add(this.label11);
            this.groupBox9.Controls.Add(this.label12);
            this.groupBox9.Font = new System.Drawing.Font("宋体", 11.25F);
            this.groupBox9.Location = new System.Drawing.Point(823, 145);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(153, 122);
            this.groupBox9.TabIndex = 13;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "数据显示";
            // 
            // Texbox_show_I
            // 
            this.Texbox_show_I.Location = new System.Drawing.Point(67, 84);
            this.Texbox_show_I.Name = "Texbox_show_I";
            this.Texbox_show_I.ReadOnly = true;
            this.Texbox_show_I.Size = new System.Drawing.Size(68, 25);
            this.Texbox_show_I.TabIndex = 16;
            this.Texbox_show_I.Text = "0";
            // 
            // Texbox_show_H
            // 
            this.Texbox_show_H.Location = new System.Drawing.Point(67, 53);
            this.Texbox_show_H.Name = "Texbox_show_H";
            this.Texbox_show_H.ReadOnly = true;
            this.Texbox_show_H.Size = new System.Drawing.Size(68, 25);
            this.Texbox_show_H.TabIndex = 15;
            this.Texbox_show_H.Text = "0";
            // 
            // Texbox_show_T
            // 
            this.Texbox_show_T.Location = new System.Drawing.Point(67, 21);
            this.Texbox_show_T.Name = "Texbox_show_T";
            this.Texbox_show_T.ReadOnly = true;
            this.Texbox_show_T.Size = new System.Drawing.Size(68, 25);
            this.Texbox_show_T.TabIndex = 14;
            this.Texbox_show_T.Text = "0";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 94);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(37, 15);
            this.label10.TabIndex = 6;
            this.label10.Text = "光照";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 56);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(37, 15);
            this.label11.TabIndex = 5;
            this.label11.Text = "湿度";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 24);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(37, 15);
            this.label12.TabIndex = 4;
            this.label12.Text = "温度";
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.S_Text_color_I);
            this.groupBox6.Controls.Add(this.S_Text_color_H);
            this.groupBox6.Controls.Add(this.S_Text_color_T);
            this.groupBox6.Controls.Add(this.label5);
            this.groupBox6.Controls.Add(this.label7);
            this.groupBox6.Controls.Add(this.label9);
            this.groupBox6.Font = new System.Drawing.Font("宋体", 11.25F);
            this.groupBox6.Location = new System.Drawing.Point(822, 283);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(153, 100);
            this.groupBox6.TabIndex = 14;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "设置曲线颜色";
            // 
            // S_Text_color_I
            // 
            this.S_Text_color_I.BackColor = System.Drawing.Color.Navy;
            this.S_Text_color_I.Location = new System.Drawing.Point(67, 73);
            this.S_Text_color_I.Multiline = true;
            this.S_Text_color_I.Name = "S_Text_color_I";
            this.S_Text_color_I.Size = new System.Drawing.Size(68, 14);
            this.S_Text_color_I.TabIndex = 18;
            this.S_Text_color_I.MouseDown += new System.Windows.Forms.MouseEventHandler(this.S_Text_color_I_MouseDown);
            // 
            // S_Text_color_H
            // 
            this.S_Text_color_H.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.S_Text_color_H.Location = new System.Drawing.Point(67, 48);
            this.S_Text_color_H.Multiline = true;
            this.S_Text_color_H.Name = "S_Text_color_H";
            this.S_Text_color_H.Size = new System.Drawing.Size(68, 14);
            this.S_Text_color_H.TabIndex = 17;
            this.S_Text_color_H.MouseDown += new System.Windows.Forms.MouseEventHandler(this.S_Text_color_H_MouseDown);
            // 
            // S_Text_color_T
            // 
            this.S_Text_color_T.BackColor = System.Drawing.Color.DarkRed;
            this.S_Text_color_T.Location = new System.Drawing.Point(67, 21);
            this.S_Text_color_T.Multiline = true;
            this.S_Text_color_T.Name = "S_Text_color_T";
            this.S_Text_color_T.Size = new System.Drawing.Size(68, 14);
            this.S_Text_color_T.TabIndex = 16;
            this.S_Text_color_T.MouseDown += new System.Windows.Forms.MouseEventHandler(this.S_Text_color_T_MouseDown);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 72);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 15);
            this.label5.TabIndex = 7;
            this.label5.Text = "光照";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 47);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(37, 15);
            this.label7.TabIndex = 6;
            this.label7.Text = "湿度";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 21);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(37, 15);
            this.label9.TabIndex = 5;
            this.label9.Text = "温度";
            // 
            // bt_Show_point
            // 
            this.bt_Show_point.Font = new System.Drawing.Font("宋体", 11.25F);
            this.bt_Show_point.Location = new System.Drawing.Point(823, 504);
            this.bt_Show_point.Name = "bt_Show_point";
            this.bt_Show_point.Size = new System.Drawing.Size(152, 43);
            this.bt_Show_point.TabIndex = 16;
            this.bt_Show_point.Text = "显示波形";
            this.bt_Show_point.UseVisualStyleBackColor = true;
            this.bt_Show_point.Click += new System.EventHandler(this.button2_Click);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.G_Text_color_I);
            this.groupBox11.Controls.Add(this.G_Text_color_H);
            this.groupBox11.Controls.Add(this.G_Text_color_T);
            this.groupBox11.Controls.Add(this.label15);
            this.groupBox11.Controls.Add(this.label14);
            this.groupBox11.Controls.Add(this.label13);
            this.groupBox11.Font = new System.Drawing.Font("宋体", 11.25F);
            this.groupBox11.Location = new System.Drawing.Point(822, 398);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(153, 100);
            this.groupBox11.TabIndex = 8;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "接收曲线颜色";
            // 
            // G_Text_color_I
            // 
            this.G_Text_color_I.BackColor = System.Drawing.Color.MediumTurquoise;
            this.G_Text_color_I.Location = new System.Drawing.Point(67, 72);
            this.G_Text_color_I.Multiline = true;
            this.G_Text_color_I.Name = "G_Text_color_I";
            this.G_Text_color_I.Size = new System.Drawing.Size(68, 14);
            this.G_Text_color_I.TabIndex = 19;
            this.G_Text_color_I.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_Text_color_I_MouseDown);
            // 
            // G_Text_color_H
            // 
            this.G_Text_color_H.BackColor = System.Drawing.Color.Green;
            this.G_Text_color_H.Location = new System.Drawing.Point(67, 48);
            this.G_Text_color_H.Multiline = true;
            this.G_Text_color_H.Name = "G_Text_color_H";
            this.G_Text_color_H.Size = new System.Drawing.Size(68, 14);
            this.G_Text_color_H.TabIndex = 18;
            this.G_Text_color_H.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_Text_color_H_MouseDown);
            // 
            // G_Text_color_T
            // 
            this.G_Text_color_T.BackColor = System.Drawing.Color.Yellow;
            this.G_Text_color_T.Location = new System.Drawing.Point(67, 21);
            this.G_Text_color_T.Multiline = true;
            this.G_Text_color_T.Name = "G_Text_color_T";
            this.G_Text_color_T.Size = new System.Drawing.Size(68, 14);
            this.G_Text_color_T.TabIndex = 17;
            this.G_Text_color_T.MouseDown += new System.Windows.Forms.MouseEventHandler(this.G_Text_color_T_MouseDown);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(6, 72);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(37, 15);
            this.label15.TabIndex = 7;
            this.label15.Text = "光照";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(6, 47);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(37, 15);
            this.label14.TabIndex = 6;
            this.label14.Text = "湿度";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(6, 21);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(37, 15);
            this.label13.TabIndex = 5;
            this.label13.Text = "温度";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.chart1);
            this.groupBox7.Font = new System.Drawing.Font("宋体", 11.25F);
            this.groupBox7.Location = new System.Drawing.Point(6, 6);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(798, 548);
            this.groupBox7.TabIndex = 3;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "波形图";
            // 
            // chart1
            // 
            chartArea1.AxisX.LabelStyle.IsEndLabelVisible = false;
            chartArea1.AxisX.MajorGrid.Enabled = false;
            chartArea1.AxisX.ScrollBar.BackColor = System.Drawing.SystemColors.ActiveCaption;
            chartArea1.AxisX.ScrollBar.ButtonColor = System.Drawing.SystemColors.ActiveCaption;
            chartArea1.AxisX.ScrollBar.LineColor = System.Drawing.SystemColors.ActiveCaption;
            chartArea1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            chartArea1.BackGradientStyle = System.Windows.Forms.DataVisualization.Charting.GradientStyle.TopBottom;
            chartArea1.BackImageTransparentColor = System.Drawing.Color.White;
            chartArea1.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            chartArea1.BorderDashStyle = System.Windows.Forms.DataVisualization.Charting.ChartDashStyle.Solid;
            chartArea1.CursorX.IsUserEnabled = true;
            chartArea1.CursorX.IsUserSelectionEnabled = true;
            chartArea1.CursorX.LineColor = System.Drawing.SystemColors.GradientActiveCaption;
            chartArea1.CursorX.SelectionColor = System.Drawing.SystemColors.ScrollBar;
            chartArea1.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea1);
            legend1.AutoFitMinFontSize = 10;
            legend1.BackColor = System.Drawing.Color.Transparent;
            legend1.BorderWidth = 2;
            legend1.Docking = System.Windows.Forms.DataVisualization.Charting.Docking.Top;
            legend1.Name = "Legend1";
            this.chart1.Legends.Add(legend1);
            this.chart1.Location = new System.Drawing.Point(6, 24);
            this.chart1.Name = "chart1";
            series1.BorderWidth = 3;
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series1.Legend = "Legend1";
            series1.Name = "设置温度值";
            series2.BorderWidth = 3;
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series2.Legend = "Legend1";
            series2.Name = "设置湿度值";
            series3.BorderWidth = 3;
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series3.Legend = "Legend1";
            series3.Name = "设置光照值";
            series4.BorderWidth = 3;
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series4.Legend = "Legend1";
            series4.Name = "获取温度值";
            series5.BorderWidth = 3;
            series5.ChartArea = "ChartArea1";
            series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series5.Legend = "Legend1";
            series5.Name = "获取湿度值";
            series6.BorderWidth = 3;
            series6.ChartArea = "ChartArea1";
            series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Spline;
            series6.Legend = "Legend1";
            series6.Name = "获取光照值";
            this.chart1.Series.Add(series1);
            this.chart1.Series.Add(series2);
            this.chart1.Series.Add(series3);
            this.chart1.Series.Add(series4);
            this.chart1.Series.Add(series5);
            this.chart1.Series.Add(series6);
            this.chart1.Size = new System.Drawing.Size(786, 517);
            this.chart1.TabIndex = 1;
            this.chart1.Text = "chart1";
            this.chart1.GetToolTipText += new System.EventHandler<System.Windows.Forms.DataVisualization.Charting.ToolTipEventArgs>(this.chart1_GetToolTipText);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.Combox_Set_I);
            this.groupBox8.Controls.Add(this.Combox_Set_H);
            this.groupBox8.Controls.Add(this.Combox_Set_T);
            this.groupBox8.Controls.Add(this.label4);
            this.groupBox8.Controls.Add(this.label2);
            this.groupBox8.Controls.Add(this.label8);
            this.groupBox8.Font = new System.Drawing.Font("宋体", 11.25F);
            this.groupBox8.Location = new System.Drawing.Point(822, 6);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(153, 124);
            this.groupBox8.TabIndex = 5;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "数据设定";
            // 
            // Combox_Set_I
            // 
            this.Combox_Set_I.FormattingEnabled = true;
            this.Combox_Set_I.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.Combox_Set_I.Location = new System.Drawing.Point(67, 93);
            this.Combox_Set_I.Name = "Combox_Set_I";
            this.Combox_Set_I.Size = new System.Drawing.Size(68, 23);
            this.Combox_Set_I.TabIndex = 9;
            this.Combox_Set_I.Text = "2";
            // 
            // Combox_Set_H
            // 
            this.Combox_Set_H.FormattingEnabled = true;
            this.Combox_Set_H.Items.AddRange(new object[] {
            "30%",
            "35%",
            "40%",
            "45%",
            "50%",
            "55%",
            "60%",
            "65%",
            "70%",
            "75%",
            "80%"});
            this.Combox_Set_H.Location = new System.Drawing.Point(67, 57);
            this.Combox_Set_H.Name = "Combox_Set_H";
            this.Combox_Set_H.Size = new System.Drawing.Size(68, 23);
            this.Combox_Set_H.TabIndex = 8;
            this.Combox_Set_H.Text = "40%";
            // 
            // Combox_Set_T
            // 
            this.Combox_Set_T.FormattingEnabled = true;
            this.Combox_Set_T.Items.AddRange(new object[] {
            "2",
            "4",
            "6",
            "8",
            "10",
            "12",
            "14",
            "16",
            "18",
            "20",
            "22",
            "24",
            "26",
            "28",
            "30",
            "32",
            "34",
            "36",
            "38",
            "40",
            "42"});
            this.Combox_Set_T.Location = new System.Drawing.Point(67, 21);
            this.Combox_Set_T.Name = "Combox_Set_T";
            this.Combox_Set_T.Size = new System.Drawing.Size(68, 23);
            this.Combox_Set_T.TabIndex = 7;
            this.Combox_Set_T.Text = "20";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 15);
            this.label4.TabIndex = 6;
            this.label4.Text = "光照";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 60);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 15);
            this.label2.TabIndex = 5;
            this.label2.Text = "湿度";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 24);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(37, 15);
            this.label8.TabIndex = 4;
            this.label8.Text = "温度";
            // 
            // Color_set
            // 
            this.Color_set.AnyColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(1003, 609);
            this.Controls.Add(this.TabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "智能农业网络监控系统";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.TabControl1.ResumeLayout(false);
            this.TabPage1.ResumeLayout(false);
            this.GroupBox5.ResumeLayout(false);
            this.GroupBox5.PerformLayout();
            this.GroupBox4.ResumeLayout(false);
            this.GroupBox4.PerformLayout();
            this.GroupBox3.ResumeLayout(false);
            this.GroupBox3.PerformLayout();
            this.GroupBox2.ResumeLayout(false);
            this.GroupBox2.PerformLayout();
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.TabPage2.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.TabControl TabControl1;
        internal System.Windows.Forms.TabPage TabPage1;
        internal System.Windows.Forms.Button Bt_Send;
        internal System.Windows.Forms.GroupBox GroupBox5;
        internal System.Windows.Forms.TextBox Text_Send;
        internal System.Windows.Forms.GroupBox GroupBox4;
        internal System.Windows.Forms.Label Lab_Indata;
        internal System.Windows.Forms.TextBox Text_Delay;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.CheckedListBox Ckbox_SendList;
        internal System.Windows.Forms.GroupBox GroupBox2;
        internal System.Windows.Forms.TextBox Text_Rev;
        internal System.Windows.Forms.TabPage TabPage2;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox Combox_Set_I;
        private System.Windows.Forms.ComboBox Combox_Set_H;
        private System.Windows.Forms.ComboBox Combox_Set_T;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox Texbox_show_I;
        private System.Windows.Forms.TextBox Texbox_show_H;
        private System.Windows.Forms.TextBox Texbox_show_T;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ColorDialog Color_set;
        private System.Windows.Forms.TextBox S_Text_color_T;
        private System.Windows.Forms.TextBox S_Text_color_I;
        private System.Windows.Forms.TextBox S_Text_color_H;
        private System.Windows.Forms.TextBox G_Text_color_H;
        private System.Windows.Forms.TextBox G_Text_color_T;
        private System.Windows.Forms.TextBox G_Text_color_I;
        private System.Windows.Forms.Button bt_Show_point;
        internal System.Windows.Forms.GroupBox GroupBox3;
        internal System.Windows.Forms.Label Lab_ClearShow;
        internal System.Windows.Forms.Label Lab_Savadata;
        internal System.Windows.Forms.CheckedListBox Ckbox_RecList;
        internal System.Windows.Forms.GroupBox GroupBox1;
        private System.Windows.Forms.PictureBox pictureBox1;
        internal System.Windows.Forms.Button Bt_Listen;
        internal System.Windows.Forms.TextBox Text_Port;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.TextBox Text_Ip;
        internal System.Windows.Forms.Label Lab_Ip;
        internal System.Windows.Forms.ComboBox Cmbox_Prot;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
    }
}

