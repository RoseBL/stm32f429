#ifndef TIME_TEST_H
#define TIME_TEST_H

#include "stm32f10x.h"

void TIM2_NVIC_Configuration(void);
void TIM2_Configuration(void);

#endif	/* TIME_TEST_H */
