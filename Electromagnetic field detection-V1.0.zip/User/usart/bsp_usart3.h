#ifndef __USART_H
#define	__USART_H


#include "stm32f10x.h"
#include <stdio.h>
#include "stdlib.h"
#include "string.h"

#define USART3_ON   1
#define USART3_OFF  0

#define MAX_RCV_LEN_3  1024

extern void USART3_Config(void);
extern void USART3_Write(USART_TypeDef* USARTx, uint8_t *Data,uint8_t len);
extern void USART3_Clear(void);
//extern volatile unsigned char  gprs_ready_flag;
//extern volatile unsigned char  gprs_ready_count;

extern unsigned char  usart3_rcv_buf[MAX_RCV_LEN_3];
extern volatile unsigned int   usart3_rcv_len;
void USART3_SendCmd(char* cmd, char* result, int timeOut);


//#if 1
//// ����3-USART3
//#define  USARTx                   USART3
//#define  USART_CLK                RCC_APB1Periph_USART3
//#define  USART_APBxClkCmd         RCC_APB1PeriphClockCmd
//#define  USART_BAUDRATE           115200

//// USART GPIO ���ź궨��
//#define  USART_GPIO_CLK           (RCC_APB2Periph_GPIOB)
//#define  USART_GPIO_APBxClkCmd    RCC_APB2PeriphClockCmd
//    
//#define  USART_TX_GPIO_PORT         GPIOB   
//#define  USART_TX_GPIO_PIN          GPIO_Pin_10
//#define  USART_RX_GPIO_PORT       GPIOB
//#define  USART_RX_GPIO_PIN        GPIO_Pin_11

//#define  USART_IRQ                USART3_IRQn
//#define  USART_IRQHandler         USART3_IRQHandler
//#endif



void USART3_Config(void);
void Usart3_SendByte( USART_TypeDef * pUSARTx, uint8_t ch);
void Usart3_SendString( USART_TypeDef * pUSARTx, char *str);
void Usart3_SendHalfWord( USART_TypeDef * pUSARTx, uint16_t ch);

#endif /* __USART_H */
