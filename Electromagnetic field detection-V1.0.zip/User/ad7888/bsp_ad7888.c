#include "bsp_ad7888.h"
#include "bsp_usart1.h"
#include "bsp_SysTick.h"


/*******************************************************************************
* Function Name  : SPI_FLASH_Init
* Description    : Initializes the peripherals used by the SPI FLASH driver.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void AD7888_SPI_Init(void)//USE
{
  GPIO_InitTypeDef GPIO_InitStructure;
  
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

  /*!< SPI_FLASH_SPI Periph clock enable */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE);
 
  
  /*!< Configure SPI_FLASH_SPI pins: SCK */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  //GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOB, &GPIO_InitStructure);

  /*!< Configure SPI_FLASH_SPI pins: MISO */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_14;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	//GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;   //����ģ������
	//GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;   //��������
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;   //��������GPIO_Mode_IPU
  //GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;   //ģ������  ������  ����
  GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;   //MOSIҪ��ģ������
  GPIO_Init(GPIOB, &GPIO_InitStructure);
    
  /*!< Configure SPI_FLASH_SPI pins: MOSI */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;   //
  GPIO_Init(GPIOB, &GPIO_InitStructure);

  /*!< Configure SPI_FLASH_SPI_CS_PIN pin: SPI_FLASH Card CS pin */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOB, &GPIO_InitStructure);

  /* Deselect the FLASH: Chip Select high */
  AD7888_CS_LOW();

}




/*******************************************************************
*   Function:    ReadFromAD7888ViaSPI
*   Description: read to the AD7888 via the SPI port.
*******************************************************************/
unsigned int ReadFromAD7888ViaSPI(unsigned char RegValue)
{
	unsigned int ReceiveData = 0;
	unsigned char ControlValue = 0;
	unsigned int i = 0;
	ControlValue = RegValue;

	/*Write Control register and Read   result data*/
	
	AD7888_CS_LOW();
	
	AD7888_CLK_LOW();
                                                   

	for(i=0; i<16; i++)
	{
		ReceiveData <<= 1;	/*Rotate data*/

		/*write register code*/  
		if(i < 8)
		{
			if(0x80 == (ControlValue & 0x80))
			{
				/*Send one to SDO pin*/
				
				AD7888_MOSI_HIGH();
			}
			else
			{
			 /*Send zero to SDO pin*/
				
				AD7888_MOSI_LOW();
			}
			ControlValue <<= 1;	/*Rotate data*/
		}

		Delay_us(3);
	
		AD7888_CLK_HIGH();
		
		if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_14) == 1)	
			{                        
				ReceiveData |= 1;
				//printf("1\n");
			}
			else
			{
				//printf("0\n");
			}
			
		Delay_us(3);
		
		AD7888_CLK_LOW();


	}
		/*bring CS high again*/
	AD7888_CS_HIGH();
	return ReceiveData;
}

/*******************************************************************
*   Function:    WriteToAD7888ViaSPI
*   Description: write to the AD7888 via the SPI port.
*******************************************************************/
void WriteToAD7888ViaSPI(unsigned char RegValue)
{
	unsigned char ControlValue = 0;
	unsigned char i;
	ControlValue=RegValue;

	AD7888_CS_LOW();
	for(i=0;i<8;i++)
	{
		
		AD7888_CLK_LOW();
		if(0x80 == (ControlValue & 0x80))
			{
				/*Send one to SDO pin*/
				AD7888_MISO_HIGH();
			}
			else
			{
				/*Send zero to SDO pin*/
				AD7888_MISO_LOW();
			}
		ControlValue <<= 1;	/*Rotate data*/
		Delay_us(3);
		
		AD7888_CLK_HIGH();
		Delay_us(3);
	}
		/*bring CS high again*/
	AD7888_CS_HIGH();
}


