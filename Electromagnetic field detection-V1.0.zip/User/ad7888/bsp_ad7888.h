#ifndef __AD7888_H
#define __AD7888_H

#include "stm32f10x.h"

#define SPI_FLASH_SPI                           SPI2
#define SPI_FLASH_SPI_CLK                       RCC_APB2Periph_SPI2
#define SPI_FLASH_SPI_SCK_PIN                   GPIO_Pin_13                  
#define SPI_FLASH_SPI_SCK_GPIO_PORT             GPIOB                       
#define SPI_FLASH_SPI_SCK_GPIO_CLK              RCC_APB2Periph_GPIOA
#define SPI_FLASH_SPI_MISO_PIN                  GPIO_Pin_14                  
#define SPI_FLASH_SPI_MISO_GPIO_PORT            GPIOB                       
#define SPI_FLASH_SPI_MISO_GPIO_CLK             RCC_APB2Periph_GPIOA
#define SPI_FLASH_SPI_MOSI_PIN                  GPIO_Pin_15                  
#define SPI_FLASH_SPI_MOSI_GPIO_PORT            GPIOB                       
#define SPI_FLASH_SPI_MOSI_GPIO_CLK             RCC_APB2Periph_GPIOA
#define SPI_FLASH_CS_PIN                        GPIO_Pin_12                  
#define SPI_FLASH_CS_GPIO_PORT                  GPIOB                      
#define SPI_FLASH_CS_GPIO_CLK                   RCC_APB2Periph_GPIOA


#define AIN_1					0x0
#define AIN_2					0x08
#define AIN_3					0x10
#define AIN_4					0x18
#define AIN_5					0x20
#define AIN_6					0x28
#define AIN_7					0x30
#define AIN_8					0x38
#define REF_IN					0x0
#define REF_EX					0x04
#define NORMAL_OPERATION		0x0
#define FULL_SHUTDOWN			0x01
#define AUTOSHUTDOWN			0x02
#define AUTOSTANDBY				0x03

#define AD7888_CS_LOW()       GPIO_ResetBits(GPIOB, GPIO_Pin_12)
#define AD7888_CS_HIGH()      GPIO_SetBits(GPIOB, GPIO_Pin_12)

#define AD7888_CLK_LOW()       GPIO_ResetBits(GPIOB, GPIO_Pin_13)
#define AD7888_CLK_HIGH()      GPIO_SetBits(GPIOB, GPIO_Pin_13)

#define AD7888_MISO_LOW()       GPIO_ResetBits(GPIOB, GPIO_Pin_14)
#define AD7888_MISO_HIGH()      GPIO_SetBits(GPIOB, GPIO_Pin_14)

#define AD7888_MOSI_LOW()       GPIO_ResetBits(GPIOB, GPIO_Pin_15)
#define AD7888_MOSI_HIGH()      GPIO_SetBits(GPIOB, GPIO_Pin_15)

#define macSPI_READ()  ((GPIOB->IDR & 14) != 0)	/* ��SDA����״̬ */

unsigned int ReadFromAD7888ViaSPI(unsigned char RegValue);
void WriteToAD7888ViaSPI(unsigned char RegValue);


void AD7888_SPI_Init(void);




#endif /* __AD7888_H */

